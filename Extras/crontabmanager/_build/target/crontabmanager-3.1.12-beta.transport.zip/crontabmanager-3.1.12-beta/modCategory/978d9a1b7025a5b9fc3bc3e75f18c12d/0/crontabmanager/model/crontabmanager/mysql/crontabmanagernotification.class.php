<?php
require_once (dirname(__DIR__) . '/crontabmanagernotification.class.php');
class CronTabManagerNotification_mysql extends CronTabManagerNotification {}