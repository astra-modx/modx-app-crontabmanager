--------------------
CronTabManager
--------------------
Author: Andrey Stepanenko <info@bustep.ru>
--------------------

A basic Extra for MODx Revolution.