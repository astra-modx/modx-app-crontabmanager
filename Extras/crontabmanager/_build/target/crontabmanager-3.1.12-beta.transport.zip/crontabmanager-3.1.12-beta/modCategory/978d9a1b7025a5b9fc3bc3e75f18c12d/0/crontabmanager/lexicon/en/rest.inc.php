<?php
include_once 'setting.inc.php';

$_lang['crontabmanager_rest'] = 'Rest';
