<?php
class CronTabManagerToken extends xPDOSimpleObject {}