<?php
class CronTabManagerHash extends xPDOSimpleObject {}