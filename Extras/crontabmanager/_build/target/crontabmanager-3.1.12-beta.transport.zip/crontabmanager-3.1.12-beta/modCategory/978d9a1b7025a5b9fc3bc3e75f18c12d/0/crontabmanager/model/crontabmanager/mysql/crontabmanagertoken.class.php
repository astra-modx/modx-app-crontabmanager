<?php
require_once (dirname(__DIR__) . '/crontabmanagertoken.class.php');
class CronTabManagerToken_mysql extends CronTabManagerToken {}