<?php
/**
 * Created by Andrey Stepanenko.
 * User: webnitros
 * Date: 15.05.2022
 * Time: 14:37
 */

namespace Webnitros\CronTabManager;


class Misc
{

    public static function when()
    {
        return [
            'every_day',
            'weekdays',
            'weekends',
            'monday',
            'tuesday',
            'wednesday',
            'thursday',
            'friday',
            'saturday',
            'sunday',
        ];
    }
}
