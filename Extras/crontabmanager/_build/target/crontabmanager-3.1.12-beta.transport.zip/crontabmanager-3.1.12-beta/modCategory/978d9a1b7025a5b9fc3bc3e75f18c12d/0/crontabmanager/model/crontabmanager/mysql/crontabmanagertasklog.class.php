<?php
require_once (dirname(__DIR__) . '/crontabmanagertasklog.class.php');
class CronTabManagerTaskLog_mysql extends CronTabManagerTaskLog {}