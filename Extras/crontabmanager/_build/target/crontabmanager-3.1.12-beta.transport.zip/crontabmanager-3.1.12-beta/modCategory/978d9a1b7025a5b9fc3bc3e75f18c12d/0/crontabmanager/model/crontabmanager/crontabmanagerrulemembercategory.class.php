<?php
class CronTabManagerRuleMemberCategory extends xPDOObject {}