<?php
class CronTabManagerCategory extends xPDOSimpleObject {}