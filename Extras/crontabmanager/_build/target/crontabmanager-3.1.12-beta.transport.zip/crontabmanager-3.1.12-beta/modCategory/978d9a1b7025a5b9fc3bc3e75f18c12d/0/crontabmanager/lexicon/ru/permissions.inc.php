<?php
include_once 'setting.inc.php';

$_lang['crontabmanager'] = 'CronTabManager';
$_lang['crontabmanager_menu'] = 'Показывать пункт меню';
$_lang['crontabmanager_create'] = 'Создавать задание';
$_lang['crontabmanager_save'] = 'Сохранять задание';
$_lang['crontabmanager_view'] = 'Просматривать задание';
$_lang['crontabmanager_list'] = 'Просматривать список заданий';
$_lang['crontabmanager_remove'] = 'Удалять задание';
$_lang['crontabmanager_run'] = 'Запускать задание из админки';
$_lang['crontabmanager_add_blocked'] = 'Добавлять блокировку по времени';
$_lang['crontabmanager_un_blocked'] = 'Снямать блокировку по времени';
$_lang['crontabmanager_unlock'] = 'Разблокировать блокировочный файл';
