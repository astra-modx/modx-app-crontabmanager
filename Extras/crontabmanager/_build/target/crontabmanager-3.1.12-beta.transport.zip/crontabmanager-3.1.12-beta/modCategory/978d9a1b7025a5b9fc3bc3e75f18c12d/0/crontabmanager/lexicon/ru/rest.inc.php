<?php
include_once 'setting.inc.php';

$_lang['crontabmanager_rest'] = 'Rest';

$_lang['crontabmanager.rest_error_method_not_found'] = 'Указанный метод [[+method]] не найден ';
