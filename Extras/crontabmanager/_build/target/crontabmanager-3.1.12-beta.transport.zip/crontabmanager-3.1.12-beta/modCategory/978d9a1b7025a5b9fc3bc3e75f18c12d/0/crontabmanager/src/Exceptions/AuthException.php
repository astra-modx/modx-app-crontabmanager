<?php
/**
 * Created by Andrey Stepanenko.
 * User: webnitros
 * Date: 09.11.2021
 * Time: 01:15
 */

namespace Webnitros\CronTabManager\Exceptions;

use Exception;

class AuthException extends Exception
{
}