<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'CronTabManagerTask',
    1 => 'CronTabManagerCategory',
    2 => 'CronTabManagerTaskLog',
    3 => 'CronTabManagerToken',
    4 => 'CronTabManagerNotification',
    5 => 'CronTabManagerRule',
  ),
  'xPDOObject' => 
  array (
    0 => 'CronTabManagerRuleMemberTask',
  ),
);