<?php
require_once (dirname(__DIR__) . '/crontabmanagertask.class.php');
class CronTabManagerTask_mysql extends CronTabManagerTask {}