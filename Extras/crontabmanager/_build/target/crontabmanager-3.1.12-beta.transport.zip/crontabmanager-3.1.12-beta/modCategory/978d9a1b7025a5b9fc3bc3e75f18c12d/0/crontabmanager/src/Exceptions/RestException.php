<?php
/**
 * Created by Andrey Stepanenko.
 * User: webnitros
 * Date: 09.11.2021
 * Time: 01:00
 */

namespace Webnitros\CronTabManager\Exceptions;

use Exception;

class RestException extends Exception
{

}