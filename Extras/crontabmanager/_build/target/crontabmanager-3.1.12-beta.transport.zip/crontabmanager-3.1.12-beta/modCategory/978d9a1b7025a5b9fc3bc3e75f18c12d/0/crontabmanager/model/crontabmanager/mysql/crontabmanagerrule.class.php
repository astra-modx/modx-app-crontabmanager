<?php
require_once (dirname(__DIR__) . '/crontabmanagerrule.class.php');
class CronTabManagerRule_mysql extends CronTabManagerRule {}