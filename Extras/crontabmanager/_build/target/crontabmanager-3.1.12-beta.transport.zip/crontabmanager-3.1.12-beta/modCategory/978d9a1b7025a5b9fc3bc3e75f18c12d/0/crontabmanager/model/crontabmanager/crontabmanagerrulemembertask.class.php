<?php
class CronTabManagerRuleMemberTask extends xPDOObject {}