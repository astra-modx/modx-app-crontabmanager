<?php
require_once (dirname(__DIR__) . '/crontabmanagerrulemembertask.class.php');
class CronTabManagerRuleMemberTask_mysql extends CronTabManagerRuleMemberTask {}